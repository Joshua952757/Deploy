from django.contrib import admin
from .models import Profile

# Registering Profile model.
admin.site.register(Profile)
