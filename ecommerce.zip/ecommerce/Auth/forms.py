from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from .models import Profile


USER_TYPES = [("BUYER", "buyer"), ("VENDOR", "vendor")] # Defines choices for user type.


class RegisterForm(UserCreationForm):
    """
    Custom registration form extending Django's UserCreationForm.

    Adds 'bio' (textarea) and 'type' (choice field) to the standard user creation fields.
    These extra fields are used to populate the associated Profile model.
    """
    bio = forms.CharField(widget=forms.Textarea) # Field for user's biography.
    type = forms.ChoiceField(choices=USER_TYPES) # Field for selecting user's role (BUYER/VENDOR).

    class Meta:
        """
        Meta class defines the model and fields for the form.
        """
        model = User
        fields = ['username', 'first_name', 'last_name', 'password1', 'password2', 'email', 'bio', 'type']