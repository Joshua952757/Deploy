from django.db import models
from django.contrib.auth.models import User

# Create your models here.


class Profile(models.Model):
    """
    User profile model extending Django's built-in User model.

    Each User has a One-to-One relationship with a Profile.
    Stores additional user information like bio and user type being either a 
    buyer or a vendor.
    """
    user_types = [("BUYER", "buyer"), ("VENDOR", "vendor")] # Defines choices for user type.

    user = models.OneToOneField(User, on_delete=models.CASCADE) # Links Profile to a User.
    bio = models.TextField(blank=True, null=True) # Optional user biography.
    type = models.CharField(choices=user_types, default="BUYER", max_length=20) # User's role or type..

    def __str__(self):
        """Returns the username of the associated User for string representation."""
        return self.user.username
