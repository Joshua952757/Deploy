from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from .forms import RegisterForm

# Create your views here.


def register(request):
    """
    Handles user registration.
    If the request method is POST, it attempts to validate and save the
    RegisterForm. If valid, it saves the user, populates the associated
    user profile's bio and type fields, and then redirects to the 'login' page.
    If the form is invalid, it re-renders the registration page with an error.
    If the request method is GET, it displays blank.
    """
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            user.profile.bio = form.cleaned_data.get('bio')
            user.profile.type = form.cleaned_data.get('type')
            print(user, user.profile) # For debugging purposes, shows the user and profile objects
            user.save()
            return redirect("login")
    else:
        form = RegisterForm()
    return render(request, 'Auth/register.html', {'form': form})


def profile(request):
    """
    Renders the user's profile page.
    This view displays the 'Auth/profile.html' template.
    """
    return render(request, 'Auth/profile.html')


def change_user_password(username, new_password):
    """
    Changes a user's password.
    Takes a username and a new_password as arguments. It retrieves the
    User object for the given username, sets the new password using
    Django's built-in set_password method,
    and then saves the updated user object to the database.
    """
    user = User.objects.get(username=username)
    user.set_password(new_password)
    user.save()