from django.urls import path
from .views import shop_list_create_api, product_list_create_api, review_list_api
urlpatterns = [
    path("shop/", shop_list_create_api),
    path("product/<int:shop_id>/", product_list_create_api),
    path("review/", review_list_api),
]
