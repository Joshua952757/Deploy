from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.authentication import SessionAuthentication, BasicAuthentication
from rest_framework.decorators import permission_classes, authentication_classes
from takemoreapp.models import Shop, Product, Review
from .serializers import ShopSerializer, ProductSerializer, ReviewSerializer
from django.shortcuts import get_object_or_404
from .tweety import post_tweet


@api_view(['GET', 'POST'])
@authentication_classes([SessionAuthentication, BasicAuthentication])
@permission_classes([IsAuthenticated])
def shop_list_create_api(request):
    """
    API endpoint for listing and creating shops.
    """
    if request.method == 'GET':
        shops = Shop.objects.all()
        serializer = ShopSerializer(shops, many=True)
        return Response(serializer.data)

    elif request.method == 'POST':
        if hasattr(request.user, 'profile') and request.user.profile.type.lower() == "vendor":
            serializer = ShopSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save(owner=request.user)
                shop_owner = request.user.username
                shop_name = serializer.data.get("name")
                shop_descrip = serializer.data.get("description")
                tweet = f"Shop name: {shop_name}\nThis shop is: {shop_descrip}\nThe owner is: {shop_owner}"
                post_tweet(tweet)
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response(
                {"message": "Only vendors can create shops."},
                status=status.HTTP_403_FORBIDDEN
            )


@api_view(['GET', 'POST'])
@authentication_classes([SessionAuthentication, BasicAuthentication])
@permission_classes([IsAuthenticated])
def product_list_create_api(request, shop_id=None):
    """
    API endpoint for listing and creating products.
    """
    if request.method == 'GET':
        if shop_id:
            shop = get_object_or_404(Shop, pk=shop_id)
            products = Product.objects.filter(shop=shop)
        else:
            products = Product.objects.all()
        serializer = ProductSerializer(products, many=True)
        return Response(serializer.data)

    elif request.method == 'POST':
        if hasattr(request.user, 'profile') and request.user.profile.type.lower() == "vendor":
            if not shop_id:
                return Response(
                    {"notce": "Shop ID must be provid."},
                    status=status.HTTP_400_BAD_REQUEST
                )

            shop = get_object_or_404(Shop, pk=shop_id)

            if request.user != shop.owner:
                return Response(
                    {"notice": "Only vendors can add products o the shop.."},
                    status=status.HTTP_403_FORBIDDEN
                )

            serializer = ProductSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save(shop=shop)
                product_name = serializer.data.get("name")
                product_descrip = serializer.data.get("description")
                product_price = serializer.data.get("price")
                shop_owner = request.user.username
            
                tweet = f"A new product, '{product_name}', has been added by {shop_owner}!\nDescription: {product_descrip}\nPrice: ${product_price}"
                post_tweet(tweet)
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response(
                    {"message": "Only vendors can add products."},
                    status=status.HTTP_403_FORBIDDEN
                )
          

@api_view(['GET'])
@permission_classes([AllowAny]) 
def list_products_api(request):
    """
    API endpoint to list all products.
    """
    products = Product.objects.all()
    serializer = ProductSerializer(products, many=True)
    return Response(serializer.data)


# get reviews for vendor only access
@api_view(['GET', 'POST'])
@authentication_classes([SessionAuthentication, BasicAuthentication])
@permission_classes([IsAuthenticated])
def review_list_api(request, product_id=None):
    """
    API endpoint for listing and creating reviews.
    """
    if request.method == 'GET':
        if product_id:
            product = get_object_or_404(Product, pk=product_id)
            reviews = Review.objects.filter(product=product)
        else:
            reviews = Review.objects.all()
        serializer = ReviewSerializer(reviews, many=True)
        return Response(serializer.data)