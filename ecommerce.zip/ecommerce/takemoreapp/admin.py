from django.contrib import admin
from .models import Shop

# Registering Profile model.
admin.site.register(Shop)
