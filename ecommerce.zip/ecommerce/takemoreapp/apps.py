from django.apps import AppConfig


class TakemoreappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'takemoreapp'
