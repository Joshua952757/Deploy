from django import forms
from .models import Shop, Product, Review

class ShopForm(forms.ModelForm):
    """
    Form for creating and updating Shop objects.
    """
    class Meta:
        model = Shop
        fields = ['name', 'description']


class ProductForm(forms.ModelForm):
    """
    Form for creating and updating Product objects.
    """
    class Meta:
        model = Product
        fields = ['name', 'description', 'price']
        
        
class ReviewForm(forms.ModelForm):
    """
    Form for creating and updating Review objects.
    """
    class Meta:
        model = Review
        fields = ['title', 'comment']