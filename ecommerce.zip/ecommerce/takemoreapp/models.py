from django.db import models
from django.contrib.auth.models import User
from rest_framework import serializers

# Create the model


class Shop(models.Model):
    """
    Represents a shop owned by a user.
    """
    owner = models.ForeignKey(User, on_delete=models.CASCADE)  # The user who owns this shop.
    name = models.CharField(max_length=255)  # Name of the shop.
    description = models.TextField()  # Description of the shop.

    def __str__(self):
        """Returns the name of the shop."""
        return self.name


class Product(models.Model):
    """
    Represents a product within a shop.
    """
    shop = models.ForeignKey(Shop, on_delete=models.CASCADE, related_name='products')  # The shop this product belongs to.
    name = models.CharField(max_length=100)  # Name of the product.
    description = models.TextField()  # Description of the product.
    price = models.DecimalField(max_digits=10, decimal_places=2)  # Price of the product.
    quantity = models.PositiveIntegerField(default=1)  # Available quantity of the product.

    def __str__(self):
        """Returns the name of the product."""
        return self.name


class Review(models.Model):
    """
    Represents a review for a product.
    """
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='reviews')  # The product being reviewed.
    buyer = models.ForeignKey(User, on_delete=models.CASCADE)  # The user who wrote the review.
    title = models.CharField(max_length=255, blank=True)  # Optional title for the review.
    comment = models.TextField()  # The review comment.
    created_at = models.DateTimeField(auto_now_add=True)  # Timestamp when the review was created.
    is_verified = models.BooleanField(default=False)  # Indicates if the reviewer purchased the product.
