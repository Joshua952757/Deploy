from django.urls import path
from . import views


urlpatterns = [
    path('', views.home, name='home'),
    path('create-shop/', views.create_shop, name='create_shop'),
    path('shop/<int:shop_id>/products/add/', views.add_product, name='add_product'),
    path('shop/<int:shop_id>/products/', views.product_list, name='product_list'),
    path('shop-list/', views.shop_list, name='shop_list'),
    path('shop-detail/<int:shop_id>/', views.shop_detail, name='shop_detail'),
    path('shop-update/<int:shop_id>/', views.shop_update, name='shop_update'),
    path('product-update/<int:product_id>', views.product_update, name='product_update'),
    path('product-detail/<int:product_id>', views.product_detail, name='product_detail'),
    path('shop-confirm-delete/<int:shop_id>', views.shop_delete, name='shop_confirm_delete'),
    path('product-confirm-delete/<int:product_id>', views.product_delete, name='product_confirm_delete'),
    path('cart/<int:product_id>/', views.cart, name='cart'),
    path('cart/view-cart/', views.view_cart, name='view_cart'),
    path('checkout/', views.checkout, name='checkout'),
    path('checkout-complete/', views.checkout_complete, name='checkout_complete'),
    path('purchased-items/', views.purchased_items, name='purchased_items'),
    path('products/<int:product_id>/review/', views.review, name='leave_review'),
]