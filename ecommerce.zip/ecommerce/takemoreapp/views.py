from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from django.core.mail import send_mail
from .forms import ShopForm, ProductForm, ReviewForm
from .models import Shop, Product, Review
from django.contrib.auth.decorators import login_required
from api.tweety import post_tweet

# Create your views here.

def home(request):
    """Renders the homepage."""
    return render(request, 'home.html', {})


def create_shop(request):
    """Handles creating a new shop, associating it with the logged-in user."""
    if request.method == 'POST':
        form = ShopForm(request.POST)
        if form.is_valid():
            shop = form.save(commit=False)
            shop.owner = request.user
            shop.save()
            shop_name = shop.name
            shop_descrip = shop.description
            shop_owner = shop.owner.username

            tweet = f"Shop name: {shop_name}\nThis shop is: {shop_descrip}\nThe owner is: {shop_owner}"
            post_tweet(tweet)
            return redirect('home')
    else:
        form = ShopForm()
    return render(request, 'create_shop.html', {'form': form})


@login_required
def shop_list(request):
    """Displays a list of all shops."""
    shops = Shop.objects.all()
    return render(request, 'shop_list.html', {'shops': shops})


def shop_detail(request, shop_id):
    """Displays details of a specific shop and its products."""
    shop = get_object_or_404(Shop, pk=shop_id)
    products = Product.objects.filter(shop=shop)
    return render(request, 'shop_detail.html', {'shop': shop, 'products': products})


def shop_update(request, shop_id):
    """Allows a shop owner to update their shop's information."""
    shop = get_object_or_404(Shop, pk=shop_id)
    if request.user != shop.owner:
        return redirect('home')
    if request.method == 'POST':
        form = ShopForm(request.POST, instance=shop)
        if form.is_valid():
            form.save()
            return redirect('shop_list')
    else:
        form = ShopForm(instance=shop)
    return render(request, 'create_shop.html', {'form': form, 'action': 'Update'})


def shop_delete(request, shop_id):
    """Allows a shop owner to delete their shop."""
    shop = get_object_or_404(Shop, pk=shop_id)
    if request.user != shop.owner:
        return redirect('home')
    if request.method == 'POST':
        shop.delete()
        return redirect('shop_list')
    return render(request, 'shop_confirm_delete.html', {'shop': shop})


def add_product(request, shop_id):
    """Allows a shop owner to add a new product to their shop."""
    shop = get_object_or_404(Shop, pk=shop_id)
    if request.user != shop.owner:
        return redirect('home')
    if request.method == 'POST':
        form = ProductForm(request.POST)
        if form.is_valid():
            product = form.save(commit=False)
            product.shop = shop
            product.save()
            product_name = product.name
            product_descrip = product.description
            product_price = product.price
            shop_owner = request.user.username
            
            tweet = f"A new product, '{product_name}', has been added by {shop_owner}!\nDescription: {product_descrip}\nPrice: ${product_price}"
            print(tweet)
            post_tweet(tweet)
            return redirect('shop_detail', shop_id=shop.id)
    else:
        form = ProductForm()
    return render(request, 'add_product.html', {'form': form, 'shop': shop})


def product_list(request, shop_id):
    """Displays a list of products for a specific shop."""
    shop = get_object_or_404(Shop, pk=shop_id)
    products = Product.objects.filter(shop=shop)
    return render(request, 'product_list.html', {'shop': shop, 'products': products})


def product_detail(request, product_id):
    """Displays details of a specific product and its reviews."""
    product = get_object_or_404(Product, pk=product_id)
    shop = product.shop
    reviews = product.reviews.all().order_by('-created_at')
    return render(request, 'product_detail.html', {'product': product, 'shop': shop, 'reviews': reviews})


def product_update(request, product_id):
    """Allows a shop owner to update a product."""
    product = get_object_or_404(Product, pk=product_id)
    shop = product.shop
    if request.user.username != shop.owner.username:
        return redirect('home')
    if request.method == 'POST':
        form = ProductForm(request.POST, instance=product)
        if form.is_valid():
            form.save()
            return redirect(reverse('shop_detail', kwargs={'shop_id': shop.id}))
    else:
        form = ProductForm(instance=product)
    return render(request, 'product_update.html', {'form': form, 'action': 'Update', 'shop': shop})


def product_delete(request, product_id):
    """Allows a shop owner to delete a product."""
    product = get_object_or_404(Product, pk=product_id)
    shop = product.shop
    if request.user != shop.owner:
        return redirect('home')
    if request.method == 'POST':
        product.delete()
        return redirect(reverse('shop_detail', kwargs={'shop_id': shop.id}))
    return render(request, 'product_confirm_delete.html', {'product': product})


def cart(request, product_id):
    """Adds a product to the user's session-based shopping cart."""
    product = Product.objects.get(pk=product_id)
    cart = request.session.get('cart', {})
    cart_item = cart.get(str(product_id))
    if cart_item:
        cart_item['quantity'] += 1
    else:
        cart_item = {'quantity': 1, 'product': product.name}
    cart[product_id] = cart_item
    request.session['cart'] = cart
    return redirect('product_detail', product_id=product_id)


def view_cart(request):
    """Displays the contents of the user's shopping cart and sends an email summary."""
    cart = request.session.get('cart', {})
    cart_items = []
    total_price = 0
    for product_id, cart_item in cart.items():
        try:
            product = Product.objects.get(pk=product_id)
            quantity = cart_item['quantity']
            product_total = product.price * quantity
            total_price += product_total
            cart_items.append({'product': product, 'quantity': quantity, 'product_total': product_total})
        except Product.DoesNotExist:
            pass
    if request.user.is_authenticated and request.user.email and cart_items:
        subject = 'Your Current Cart Summary'
        message = f"Hello {request.user.username or 'User'},\n\n" \
                  f"Here are the items in your cart:\n"
        for item in cart_items:
            message += f"- {item['product'].name} (Qty: {item['quantity']}) - R{item['product_total']:.2f}\n"
        message += f"\nTotal: R{total_price:.2f}"
        try:
            send_mail(subject, message, [request.user.email], fail_silently=True)
        except Exception as e:
            print(f"Failed to send cart email: {e}")
    return render(request, 'cart.html', {'cart_items': cart_items, 'total_price': total_price})


def checkout(request):
    """Handles the checkout process, clearing the cart and sending a confirmation email."""
    cart = request.session.get('cart', {})
    if not cart:
        return redirect('view_cart')
    if request.method == 'POST':
        purchased_product_ids = request.session.get('purchased_product_ids', [])
        item_info_for_email = ""
        for product_id_str in cart.keys():
            product_id = int(product_id_str)
            if product_id not in purchased_product_ids:
                purchased_product_ids.append(product_id)
            try:
                product = Product.objects.get(id=product_id)
                item_info_for_email += f"\n- {product.name} (R{product.price:.2f})"
            except Product.DoesNotExist:
                item_info_for_email += f"\n- Unknown Product (ID: {product_id_str})"
        request.session['purchased_product_ids'] = purchased_product_ids
        if request.user.is_authenticated:
            user_email = request.user.email
            if user_email:
                subject = 'Your Order Confirmation'
                message = f'Thank you for your purchase! Your order has been placed successfully.' \
                          f'\n\nYour purchased items:{item_info_for_email}'
                from_email = 'no-reply@yourstore.com'
                recipient_list = [user_email]
                try:
                    send_mail(subject, message, from_email, recipient_list, fail_silently=False)
                    print(f"Confirmation email sent to {user_email} (or printed to console)")
                except Exception as e:
                    print(f"Error sending email: {e}")
        request.session['cart'] = {}
        return redirect('checkout_complete')
    return render(request, 'checkout.html')


def checkout_complete(request):
    """Renders the checkout completion page."""
    return render(request, 'checkout_complete.html', {})


def purchased_items(request):
    """Displays a list of products previously purchased by the user."""
    purchased_ids = request.session.get('purchased_product_ids', [])
    products_list = []
    for product_id in purchased_ids:
        try:
            product = Product.objects.get(id=product_id)
            products_list.append(product)
        except Product.DoesNotExist:
            print(f"Warning: This product {product_id} is not found in database for purchased items list.")
            pass
    return render(request, 'purchased_items.html', {'products': products_list})


def review(request, product_id):
    """
    Handles product reviews. Users can leave or update a review.
    A review is marked as 'verified' if the user has purchased the product.
    """
    product = get_object_or_404(Product, pk=product_id)
    existing_review = Review.objects.filter(product=product, buyer=request.user).first()
    purchased_product_ids = request.session.get('purchased_product_ids', [])
    is_user_verified_for_product = product.id in purchased_product_ids

    if request.method == 'POST':
        form = ReviewForm(request.POST, instance=existing_review)
        if form.is_valid():
            review = form.save(commit=False)
            review.product = product
            review.buyer = request.user
            review.is_verified = is_user_verified_for_product
            review.save()
            return redirect('product_detail', product_id=product.id)
    else:
        form = ReviewForm(instance=existing_review)

    return render(request, 'leave_review.html', {
        'form': form,
        'product': product,
        'existing_review': existing_review,
        'is_user_verified_for_product': is_user_verified_for_product
    })