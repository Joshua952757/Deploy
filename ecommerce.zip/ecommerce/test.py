# class Person:
#     def __init__(self):
#         self.title = "john"
        
#     def __str__(self):
#         return f"name: {self.title}"
        

# person1 = Person()
# print(person1)

def display_greeting_message(name):
    print(f"Hello, {name}")